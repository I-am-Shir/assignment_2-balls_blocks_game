import biuoop.KeyboardSensor;

import java.util.List;

public class GameFlow {
    private AnimationRunner animationRunner;
    private KeyboardSensor keyboardSensor;
    ScoreIndicator scoreIndicator;
    private Counter lives;
    private Counter score;
    private boolean result;
    private int width;
    private int height;

    public GameFlow(AnimationRunner ar, KeyboardSensor ks, int lives, int width, int height) {
        this.score = new Counter(0);
        this.lives = new Counter(lives);
        this.animationRunner = ar;
        this.keyboardSensor = ks;
        this.result = true;
        this.width = width;
        this.height = height;
    }

    public void runLevels(List<LevelInformation> levels) {
        for (LevelInformation levelInfo : levels) {

            GameLevel level = new GameLevel(levelInfo,
                    this.keyboardSensor,
                    this.animationRunner, this.score, this.lives,this.width, this.height);
                    this.scoreIndicator = new ScoreIndicator(this.score, this.lives, levelInfo.levelName());
            level.addSprite(this.scoreIndicator);

            //level.initialize();

            while (this.lives.getValue() > 0) {
                level.run();
                if (level.wonLevel()) {
                    this.score.increase(100);
                    break;
                } else {
                    this.lives.decrease(1);
                }
            }
            EndScreen endScreen = new EndScreen(false,this.score);
            }
        EndScreen endScreen = new EndScreen(true,this.score);
        }
}

