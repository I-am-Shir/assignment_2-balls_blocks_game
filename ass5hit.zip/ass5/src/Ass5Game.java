/**
 * main.
 */
public class Ass5Game {
    /**
     * running the main.
     *
     * @param args not used.
     */
    public static void main(String[] args) {
        Game game = new Game();
        game.initialize();
        game.run();
    }
}
